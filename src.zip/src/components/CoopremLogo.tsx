import React from 'react';

// Este componente é um placeholder para o logo.
// Um arquivo .tsx não pode estar vazio para ser um módulo válido.
const CoopremLogo: React.FC = () => {
  return null; 
};

export default CoopremLogo;
