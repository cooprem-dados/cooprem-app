import { Product } from './types';


export const PRODUCTS: Product[] = [
  Product.Consorcio,
  Product.Seguro,
  Product.RDC,
  Product.LCA,
  Product.Credito,
  Product.Previdencia,
  Product.Compliance,
  Product.Cobranca,
  Product.SIPAG,
];